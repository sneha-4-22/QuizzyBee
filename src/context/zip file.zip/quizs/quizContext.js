import { createContext } from "react";

const quizContext = createContext(); //This Context will hold all the states realted to note

export default quizContext;